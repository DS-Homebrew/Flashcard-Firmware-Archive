Fixed: cant run with 1.41 version DSi.

Note: This is fireware update, not a OS update. 
Please confirm the language version of your DSONEi, then download the correct version of fireware. If you cant confirm it, please copy both Eng & CHS version to the root of your micro sd card.


About flash fireware: Just try to re-flash it if failed. 

Q: What's the function of the Firmware writer? 
A: Only use in this situation: If the software of console upgraded and do not recognize DSONEi. Firmware writer can renew the firmware of DSONEi. And DSONEi can work again. 
  
Q: How to use Firmware writer? 
A: Please download Newest Firmware from http://eng.supercard.sc. Copy downloaded firmware to microSD insert into DSONEi then insert into Firmware writer then into USB port for power supply and operation. No extra software need, the Firmware writer will renew the firmware of DSONEi automatic. 8 Mins. needed. Flashing light mean renew in progress. Green light mean renew finished. Red light mean renew failed. If failed, please repeat the progress.

 


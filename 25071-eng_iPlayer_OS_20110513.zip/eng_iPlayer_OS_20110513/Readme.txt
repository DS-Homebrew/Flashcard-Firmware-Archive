2011.5.13
Compatible DSi firmware 1.4.2(chinese 1.4.3)

2009.9.15
1. Add Korean to be a selectable language
2. Fix the bug which leads being unable to play next when screen is closed
3. Fix that some kind of TF cards (CLASS 6) could not be identified
4. Fix the display mistake of the interface menu  

2010.3.5
1. Fixed the bug which can not run homebrew file more than 4M.
2. Optimized the subtitle, automatic delete "<i></i>" 





Brief Manual & FAQ

Q: First time use iPlayer?
A: Hardware: iPlayer, MicroSD.
    Software: iPlayer OS.
    Step 1: Download the iPlayer OS from www.dsiplayer.com
    Step 2: Unzip the software package and copy it folder into MicroSD.
    Step 3: Insert MicroSD into iPlayer, insert iPlayer into DS. Now you can enjoy it.


Q: What is iPlayer OS? How to copy the software into MicroSD?
A: iPlayer OS is folder "_system". Please copy the "_system" folder into MicroSD ROOT.

Q: Why I always get " An error has occurred ..." message on DSi?
A: Your DSi firmware must be v1.4 or higher, please upgrade the iPlayer firmware.


Q: How to upgrade the firmware of iPlayer?
1. [For DSi firmware under v1.4]
a. copy "update.dat" file into MicroSD ROOT.
b. Insert MicroSD into iPlayer, insert iPlayer into DS.
c. Turn on the power, iPlayer will detect the upgrade file automaticly.

2. [Very Important for NDSi v1.4]
a. copy "update.dat" file into MicroSD
b. Turn on the power, you will get "An error has occurred..." error message. 
c. When this message displayed, please wait 2 mins, iPlayer is upgrading. (If turn off power at this moment, iPlayer will dead). 
d. After 2 mins, iPlayer is upgraded. Please turn off DSi power and turn on again. Now you can enjoy it.
